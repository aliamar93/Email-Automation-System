import { Bell, Database, Menu, Search } from 'lucide-react'

interface TopBarProps {
    OnMenuClick: () => void
}


export function TopBar({ OnMenuClick }: TopBarProps) {
    return (
        <header className="sticky top-0 z-40 h-16 border-b border-slate-200 bg-white">
            <div className="flex h-full items-center gap-3 px-4 sm:px-6">
                
                {/* Mobile menu button (bari screen par chhup jata hai) */}
                <button type="button" onClick={OnMenuClick} aria-label="Open Menu" className="grid h-10 w-10 place-items-center rounded-lg 
text-slate-600 hover:bg-slate-100 lg:hidden">
                    <Menu size={20} />
                </button>

                {/* Logo */}
                <span className="hidden h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br from-blue-500 to-blue-700 text-white sm:grid">
                    <Database size={21} />
                </span>

                {/* App ka naam */}
                <div className="min-w-0">
                    <p className="truncate text-[16px] font-bold text-slate-900">
                        Scheduled SQL Report & Email Automation System
                    </p>
                    <p className="hiddem truncate text-[12.5px] text-slate-500 sm:block">
                        Automate Your Data. Deliver Insights
                    </p>
                </div>

                { /* Search Box */}
                <div className="relative ml-auto hidden w-[300px] md:block">
                    <Search size={16} className="absolute top-1/2 left-3 -translate-y-1/2 text-slate-400" />
                    <input type="search" placeholder="Search reports..." className="h-10 w-full rounded-lg border border-slate-200 bg-slate-50 pr-3 pl-9 text-[13.5px] outline-none focus:border-blue-500 focus:bg-white" />
                </div>

                { /* Notification Bell */}
                <button type="button" aria-label="Notifications" className="ml-auto grid h-10 w-10 place-items-center rounded-lg text-slate-500 hover:bg-slate-100 md:ml-0">
                    <Bell size={19} />
                </button>

                { /* User */}
                <div className="flex items-center gap-2.5">
                    <span className="grid h-9 w-9 place-items-center rounded-full bg-blue-600 text-[13px] font-bold text-white">
                        JD
                    </span>
                    <span className="hidden text-[13.5px] font-semibold text-slate-700 lg:block">John Doe</span>
                </div>

            </div>
        </header>
    )
}