import { Building2, X } from 'lucide-react'
import { NavLink } from 'react-router'
import { NAV_ITEMS } from './navItems'


interface SidebarProps {
    open: boolean
    onClose: () => void
}


export function Sidebar({ open, onClose }: SidebarProps) {
    return (
        <>
            {/* Mobile par sidebar ke peeche dark parda. Click karne se menu band. */}
            {open && <div onClick={onClose} className="fixed inset-0 z-40 bg-slate-900/50 lg:hidden" />}

            <aside
                className={`fixed inset-y-0 left-0 z-50 flex w-[248px] flex-col bg-linear-to-b from-navy-900 to-navy-800 transition-transform duration-200 lg:top-16 lg:z-30 lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'
                    }`}
            >
                {/* Close button (sirf mobile par) */}
                <div className="flex items-center justify-between border-b border-white/10 px-4 py-4 lg:hidden">
                    <p className="text-[13px] font-semibold text-white">Menu</p>
                    <button
                        type="button"
                        onClick={onClose}
                        aria-label="Close menu"
                        className="grid h-8 w-8 place-items-center rounded-lg text-slate-300 hover:bg-white/10"
                    >
                        <X size={17} />
                    </button>
                </div>

                {/* Menu items */}
                <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
                    {NAV_ITEMS.map((item) => {
                        const Icon = item.icon

                        return (
                            <NavLink
                                key={item.path}
                                to={item.path}
                                end={item.path === '/'}
                                onClick={onClose}
                                className={({ isActive }) =>
                                    `flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13.5px] transition-colors ${isActive
                                        ? 'bg-blue-600 font-semibold text-white shadow-lg shadow-blue-900/30'
                                        : 'text-slate-300 hover:bg-white/5 hover:text-white'
                                    }`
                                }
                            >
                                <Icon size={18} />
                                {item.label}
                            </NavLink>
                        )
                    })}
                </nav>

                {/* Neeche company ka naam */}
                <div className="border-t border-white/10 px-4 py-4">
                    <div className="flex items-start gap-3">
                        <Building2 size={22} className="mt-0.5 shrink-0 text-slate-400" />
                        <div>
                            <p className="text-[12.5px] font-semibold text-slate-200">Your Company Logistics & Warehouse ERP</p>
                            <p className="text-[11px] text-slate-400">v1.0.0</p>
                        </div>
                    </div>
                </div>
            </aside>
        </>
    )
}


// export function Sidebar({ open, onClose }: SidebarProps) {
//     return (

//         <>
//             {/* Mobile par sidebar ke peeche dark parda. Click karne se menu band. */}
//             {open && <div onClick={onClose} className="fixed inset-0 z-40 bg-slate-900/50 lg:hidden" />}

//             <aside
//                 className={`fixed inset-y-0 left-0 z-50 flex w-[248px] flex-col bg-linear-to-b from-navy-900 to-navy-800 transition-transform duration-200 lg:top-16 lg:z-30 lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}
//             >
//                 {/* Close button (sirf mobile par) */}
//                 <div className="flex items-center justify-between border-b border-white/10 px-4 py-4 lg:hidden">
//                     <p className="text-[13px] font-semibold text-white">Menu</p>
//                     <button
//                         type="button"
//                         onClick={onClose}
//                         aria-label="Close menu"
//                         className="grid h-8 w-8 place-items-center rounded-lg text-slate-300 hover:bg-white/10"
//                     >
//                         <X size={17} />
//                     </button>
//                 </div>

//                 {/* Menu items */}
//                 <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
//                     {NAV_ITEMS.map((item) => {
//                         const Icon = item.icon

//                         return (
//                             <NavLink
//                                 key={item.path}
//                                 to={item.path}
//                                 end={item.path === '/'}
//                                 onClick={onClose}
//                                 className={({ isActive }) =>
//                                     `flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13.5px] transition-colors ${isActive
//                                         ? 'bg-blue-600 font-semibold text-white shadow-lg shadow-blue-900/30'
//                                         : 'text-slate-300 hover:bg-white/5 hover:text-white'
//                                     }`
//                                 }
//                             >
//                                 <Icon size={18} />
//                                 {item.label}
//                             </NavLink>
//                         )
//                     })}
//                 </nav>

//                 {/* Neeche company ka naam */}
//                 <div className="border-t border-white/10 px-4 py-4">
//                     <div className="flex items-start gap-3">
//                         <Building2 size={22} className="mt-0.5 shrink-0 text-slate-400" />
//                         <div>
//                             <p className="text-[12.5px] font-semibold text-slate-200">Your Company Logistics & Warehouse ERP</p>
//                             <p className="text-[11px] text-slate-400">v1.0.0</p>
//                         </div>
//                     </div>
//                 </div>
//             </aside>
//         </>
//     )
// }