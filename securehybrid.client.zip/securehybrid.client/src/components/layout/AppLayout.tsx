import { useState } from 'react'
import { Outlet } from 'react-router'
import { Sidebar } from './Sidebar'
import { TopBar } from './TopBar'


// Har page ke gird ek hi frame: TopBar + Sidebar + content
export function AppLayout() {
    const [menuOpen, setMenuOpen] = useState(false)

    return (
        <div className="min-h-screen">
            <TopBar OnMenuClick={() => setMenuOpen(true)} />
            <Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />

            <div className="lg:pl-[248px]">
                <main className="mx-auto max-w-[1680px] space-y-5 p-4 sm:p-6">
                    <Outlet />
                </main>
            </div>
        </div>
    )
}