interface PageHeaderProps {
    title: string
    subtitle?: string // "?" = ye prop optional hai
}




export function PageHeader({ title, subtitle }: PageHeaderProps) {
    return (
        <div>
            <h1 className="text-[28px] font-bold text-slate-900"> {title}</h1>
            {subtitle && <p className="mt-1 text-[14px] text-slate-500">{subtitle}</p>}
        </div>
    )
}