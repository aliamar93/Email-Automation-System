import { PageHeader } from '../../components/UI/PageHeader'


export function DashboardPage() {
    return (
        <>
            <PageHeader title="Dashboard" subtitle="Every scheduled SQL report, delivery and failure in one place." />

            {/* Sample cards. Asli numbers baad mein data se aayenge. */}
            <div className="grid gap-4 sm:grid-cols-6">
                <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <span className="h-11 w-11 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-600">
                        <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                            <path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8l-5-5z"></path>
                            <path d="M14 3v5h5"></path>
                        </svg>
                    </span>
                    <div className="min-w-0">
                        <p className="text-[24px] font-bold text-slate-900">8</p>
                        <p className="text-[13px] text-slate-500">Total reports</p>
                    </div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <p className="text-[24px] font-bold text-emerald-600">5</p>
                    <p className="text-[13px] text-slate-500">Active reports</p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <p className="text-[24px] font-bold text-red-600">2</p>
                    <p className="text-[13px] text-slate-500">Disabled Reports</p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <p className="text-[24px] font-bold text-slate-900">3</p>
                    <p className="text-[13px] text-slate-500">Failed (24 h)</p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <p className="text-[24px] font-bold text-emerald-600">12</p>
                    <p className="text-[13px] text-slate-500">Reports Sent Today</p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <p className="text-[24px] font-bold text-red-600">98.5%</p>
                    <p className="text-[13px] text-slate-500">Success Rate (7 d)</p>
                </div>
            </div>

        </>
    )
}