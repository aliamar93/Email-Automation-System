import { PageHeader } from '../../components/UI/PageHeader'



export function ReportsPage() {
    return (
        <>
            <PageHeader title="Scheduled Reports" subtitle="Create, schedule and monitor the SQL reports that are emailed automatically." />

            <div className="rounded-xl border border-slate-200 bg-white p-10 text-center text-[14px] text-slate-500">The reports table comes here (next step).</div>
        </>
    )
}